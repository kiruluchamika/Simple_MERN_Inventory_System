import 'express-async-errors'; // no exports; enables async error bubbling
